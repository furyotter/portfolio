document.addEventListener('DOMContentLoaded', () => {
  const generateBtn = document.getElementById('generateBtn');
  const loading = document.getElementById('loading');
  const errorElement = document.getElementById('error');
  const questionsContainer = document.getElementById('questionsContainer');

  // 设置面板元素
  const settingsToggle = document.getElementById('settingsToggle');
  const settingsPanel = document.getElementById('settingsPanel');
  const settingsArrow = document.getElementById('settingsArrow');
  const apiUrlInput = document.getElementById('apiUrl');
  const apiKeyInput = document.getElementById('apiKey');
  const modelNameInput = document.getElementById('modelName');
  const saveSettingsBtn = document.getElementById('saveSettingsBtn');
  const saveHint = document.getElementById('saveHint');

  // 存储职位信息
  let currentJobInfo = null;

  // 当前生效的设置
  let currentSettings = {
    apiUrl: config.API_URL,
    apiKey: config.API_KEY,
    model: config.MODEL
  };

  // ========== 设置面板 ==========
  function toggleSettings() {
    const isOpen = settingsPanel.classList.toggle('open');
    settingsArrow.textContent = isOpen ? '▲' : '▼';
  }

  settingsToggle.addEventListener('click', toggleSettings);

  async function loadSettings() {
    try {
      const stored = await chrome.storage.local.get(['apiUrl', 'apiKey', 'model']);
      currentSettings.apiUrl = stored.apiUrl || config.API_URL;
      currentSettings.apiKey = stored.apiKey || config.API_KEY;
      currentSettings.model = stored.model || config.MODEL;

      apiUrlInput.value = currentSettings.apiUrl;
      apiKeyInput.value = currentSettings.apiKey;
      modelNameInput.value = currentSettings.model;

      console.log('Settings loaded:', {
        hasUrl: !!currentSettings.apiUrl,
        hasKey: !!currentSettings.apiKey,
        model: currentSettings.model
      });
    } catch (e) {
      console.error('Failed to load settings:', e);
    }
  }

  async function saveSettings() {
    const newSettings = {
      apiUrl: apiUrlInput.value.trim(),
      apiKey: apiKeyInput.value.trim(),
      model: modelNameInput.value.trim()
    };

    if (!newSettings.apiUrl) {
      saveHint.textContent = '请填写 API 地址';
      saveHint.style.color = '#e53e3e';
      return;
    }
    if (!newSettings.apiKey) {
      saveHint.textContent = '请填写 API Key';
      saveHint.style.color = '#e53e3e';
      return;
    }
    if (!newSettings.model) {
      saveHint.textContent = '请填写模型名称';
      saveHint.style.color = '#e53e3e';
      return;
    }

    try {
      await chrome.storage.local.set(newSettings);
      currentSettings = newSettings;
      saveHint.textContent = '✅ 保存成功';
      saveHint.style.color = '#38a169';
      setTimeout(() => { saveHint.textContent = ''; }, 2000);
    } catch (e) {
      saveHint.textContent = '保存失败：' + e.message;
      saveHint.style.color = '#e53e3e';
    }
  }

  saveSettingsBtn.addEventListener('click', saveSettings);

  // ========== 自动保存（解决 popup 关闭后内容丢失）==========
  let autoSaveTimer = null;

  async function autoSave() {
    const draft = {
      apiUrl: apiUrlInput.value.trim(),
      apiKey: apiKeyInput.value.trim(),
      model: modelNameInput.value.trim()
    };
    try {
      await chrome.storage.local.set(draft);
      currentSettings = draft;
      saveHint.textContent = '✅ 已自动保存';
      saveHint.style.color = '#38a169';
      setTimeout(() => { if (saveHint.textContent === '✅ 已自动保存') saveHint.textContent = ''; }, 2000);
    } catch (e) {
      console.error('Auto save failed:', e);
    }
  }

  function debounceAutoSave() {
    clearTimeout(autoSaveTimer);
    autoSaveTimer = setTimeout(autoSave, 400);
  }

  [apiUrlInput, apiKeyInput, modelNameInput].forEach((input) => {
    input.addEventListener('input', debounceAutoSave);
  });

  // 全局错误处理
  window.onerror = function(message, source, lineno, colno, error) {
    console.error('Global error:', { message, source, lineno, colno, error });
    errorElement.textContent = '发生错误：' + message;
    errorElement.style.display = 'block';
    return false;
  };

  window.onunhandledrejection = function(event) {
    console.error('Unhandled promise rejection:', event.reason);
    errorElement.textContent = '发生错误：' + event.reason;
    errorElement.style.display = 'block';
  };

  // ========== 获取职位信息 ==========
  chrome.tabs.query({active: true, currentWindow: true}, async (tabs) => {
    try {
      const currentTab = tabs[0];
      const response = await chrome.tabs.sendMessage(currentTab.id, {action: 'getJobInfo'});

      if (response && response.title) {
        document.getElementById('jobTitle').textContent = response.title;
        document.getElementById('jobRequirements').textContent = `经验要求：${response.experience}`;
        document.getElementById('jobDescription').innerHTML = response.description.replace(/\n/g, '<br>');
        currentJobInfo = response;
        generateBtn.disabled = false;
      } else {
        throw new Error('无法获取职位信息');
      }
    } catch (error) {
      console.error('Error:', error);
      let msg = '无法获取职位信息';
      if (error && error.message) {
        msg += '：' + error.message;
      }
      msg += '。请确认当前在 BOSS 直聘职位详情页，然后刷新页面重试。';
      errorElement.textContent = msg;
      errorElement.style.display = 'block';
      generateBtn.disabled = true;
    }
  });

  // 规范化 API URL：如果用户只填了域名，自动补全 /v1/chat/completions
  function normalizeApiUrl(url) {
    url = url.trim().replace(/\/+$/, '');
    if (!url.includes('/chat/completions')) {
      url = url + '/v1/chat/completions';
    }
    return url;
  }

  // ========== 生成面试题 ==========
  async function generateInterviewQuestions(jobInfo) {
    if (!currentSettings.apiUrl || !currentSettings.apiKey || !currentSettings.model) {
      throw new Error('请先点击「模型设置」填写 API 地址、Key 和模型名称');
    }

    const apiUrl = normalizeApiUrl(currentSettings.apiUrl);
    console.log('Using API URL:', apiUrl);

    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${currentSettings.apiKey}`
      },
      body: JSON.stringify({
        model: currentSettings.model,
        messages: [
          {
            role: "system",
            content: "你是一个专业的面试官，负责根据职位信息生成有针对性的面试问题。"
          },
          {
            role: "user",
            content: `在生成面试题的时候，你是一名经验丰富的面试官，想要全方位考察候选人和招聘职位的契合度以及候选人的能力，你要招聘的岗位是${jobInfo.title}，工作内容和任职要求是${jobInfo.description}，经验要求是${jobInfo.experience}。请根据职位名称、工作内容、经验要求，生成在面试这个岗位的候选人时，你最关心、最想要问的问题，题目限制为5个。

在生成面试题的回答时，你是一名正在参加面试的求职者，擅长用专业知识+清晰易懂的案例阐明自己的思路并通过流畅的表达回答问题。你需要：
1. 分析并概括面试问题的考核点。
2. 分析并给出面试问题的回答思路。
3. 以第一人称进行叙述，详细地阐述面试问题的答案，可适当举例进行说明，但不要以第一人称编造案例。

请按照以下格式生成回答（一定要确保是合法的JSON格式）：
{
  "questions": [
    {
      "question": "问题内容",
      "analysis": "考核点分析",
      "answer": "建议回答",
      "tips": "回答思路"
    }
  ]
}`
          }
        ],
        temperature: 0.7,
        max_tokens: 4000,
        stream: false
      })
    };

    try {
      const response = await fetch(apiUrl, options);
      if (!response.ok) {
        throw new Error(`API请求失败: ${response.status}`);
      }

      const data = await response.json();
      const content = data.choices[0].message.content;

      const jsonStart = content.indexOf('{');
      const jsonEnd = content.lastIndexOf('}') + 1;

      if (jsonStart === -1 || jsonEnd === -1) {
        throw new Error('API返回的内容中没有找到JSON数据');
      }

      const jsonStr = content.slice(jsonStart, jsonEnd);
      const parsed = JSON.parse(jsonStr);

      if (!parsed.questions || !Array.isArray(parsed.questions)) {
        throw new Error('API返回格式错误：缺少questions数组');
      }

      return parsed.questions;
    } catch (error) {
      console.error('生成面试题时出错:', error);
      throw error;
    }
  }

  // ========== 显示面试题 ==========
  function displayQuestions(questions) {
    if (!Array.isArray(questions)) {
      throw new Error('Questions must be an array');
    }

    const container = document.getElementById('questionsContainer');
    container.innerHTML = '';

    questions.forEach((item, index) => {
      if (!item.question || !item.answer || !item.analysis || !item.tips) {
        console.warn('Invalid question item:', item);
        return;
      }
      if (typeof item.question !== 'string' || typeof item.answer !== 'string' || typeof item.analysis !== 'string' || typeof item.tips !== 'string') {
        console.warn('Invalid question item type:', item);
        return;
      }
      const questionElement = document.createElement('div');
      questionElement.className = 'question-item';
      questionElement.innerHTML = `
        <div class="question">问题 ${index + 1}：${item.question}</div>
        <div class="analysis"><span class="label">考核点</span>${item.analysis}</div>
        <div class="answer"><span class="label">参考回答</span>${item.answer.replace(/\n/g, '<br>')}</div>
        <div class="tips"><span class="label">💡 答题思路</span>${item.tips}</div>
      `;
      container.appendChild(questionElement);
    });

    container.style.display = 'block';
  }

  generateBtn.addEventListener('click', async () => {
    console.log('Generate button clicked');

    if (!currentJobInfo) {
      console.error('No job info available');
      errorElement.textContent = '请先获取职位信息';
      errorElement.style.display = 'block';
      return;
    }

    console.log('Current job info:', currentJobInfo);

    try {
      loading.style.display = 'block';
      errorElement.style.display = 'none';
      generateBtn.disabled = true;
      questionsContainer.innerHTML = '';

      console.log('Starting to generate interview questions');
      const questions = await generateInterviewQuestions(currentJobInfo);
      console.log('Generated questions:', questions);

      questionsContainer.style.display = 'block';
      displayQuestions(questions);
    } catch (err) {
      console.error('Error in click handler:', err);
      errorElement.textContent = '生成面试题时出错，请重试：' + err.message;
      errorElement.style.display = 'block';
    } finally {
      loading.style.display = 'none';
      generateBtn.disabled = false;
    }
  });

  // 初始化：加载设置
  loadSettings();
});
