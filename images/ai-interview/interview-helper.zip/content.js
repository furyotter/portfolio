console.log('Content script loaded');

// 防止重复注入
if (window.hasRun) {
  console.log('Content script already injected, skipping...');
} else {
  window.hasRun = true;

  // 等待元素出现在页面上
  function waitForElement(selector, timeout = 5000) {
    return new Promise((resolve) => {
      const el = document.querySelector(selector);
      if (el) {
        return resolve(el);
      }

      const observer = new MutationObserver(() => {
        const found = document.querySelector(selector);
        if (found) {
          observer.disconnect();
          resolve(found);
        }
      });

      observer.observe(document.body, {
        childList: true,
        subtree: true,
      });

      setTimeout(() => {
        observer.disconnect();
        resolve(null);
      }, timeout);
    });
  }

  // 按优先级尝试多个选择器，返回第一个匹配且有文本的元素
  function queryFirst(selectors) {
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el && el.textContent.trim()) {
        return el;
      }
    }
    return null;
  }

  // 等待多个选择器中的任意一个出现
  async function waitForAny(selectors, timeout = 5000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const found = queryFirst(selectors);
      if (found) return found;
      await new Promise((r) => setTimeout(r, 300));
    }
    return null;
  }

  // 获取元素纯文本，排除 style/script/noscript/link 等标签内容
  function getCleanText(el) {
    if (!el) return '';
    const clone = el.cloneNode(true);
    clone
      .querySelectorAll('style, script, noscript, link, meta')
      .forEach((e) => e.remove());
    return clone.textContent.trim();
  }

  // 智能提取经验/学历/标签
  function extractExperienceAndLabels() {
    const expPatterns = [
      /(\d+[-～~]\d+年)/,
      /(\d+年以上)/,
      /(经验不限)/,
      /(应届)/,
      /(在校\/应届)/,
      /(\d+年以内)/,
      /(\d+年及以上)/,
      /(\d+[-～~]\d+年经验)/,
    ];

    const eduPatterns = [
      /(本科)/,
      /(大专)/,
      /(硕士)/,
      /(博士)/,
      /(学历不限)/,
      /(高中)/,
      /(中专\/中技)/,
      /(初中及以下)/,
    ];

    const searchRoots = [
      document.querySelector('.job-detail-box'),
      document.querySelector('.info-primary'),
      document.querySelector('.job-primary'),
      document.body,
    ];

    let experience = null;
    let education = null;

    for (const root of searchRoots) {
      if (!root) continue;

      const tagEls = root.querySelectorAll(
        'span, div, p, li, em, .tag-item, .job-label, .job-tag',
      );
      for (const el of tagEls) {
        if (
          el.closest(
            '.desc, .job-sec-text, .detail-bottom-text, .job-description',
          )
        )
          continue;
        const text = el.textContent.trim();
        if (!text || text.length > 30) continue;

        for (const pattern of expPatterns) {
          const match = text.match(pattern);
          if (match && !experience) {
            experience = match[1];
          }
        }

        for (const pattern of eduPatterns) {
          const match = text.match(pattern);
          if (match && !education) {
            education = match[1];
          }
        }
      }

      if (experience) break;
    }

    const parts = [];
    if (experience) parts.push(experience);
    if (education) parts.push(education);

    return parts.length > 0 ? parts.join(' | ') : '经验不限';
  }

  // 从页面标题中提取职位名（兜底方案）
  function extractTitleFromPage() {
    const title = document.title;
    // 常见格式: "【公司招聘】职位名-BOSS直聘" 或 "职位名招聘-公司-BOSS直聘"
    const match1 = title.match(/【.+?】(.*?)(?:-|\s*[·|-]\s*)/);
    if (match1) return match1[1].trim();

    const match2 = title.match(/^(.*?)(?:-|\s*[·|-]\s*).*?BOSS直聘/);
    if (match2) return match2[1].trim();

    return '';
  }

  // 通过文本特征寻找职位描述（兜底方案）
  function findDescriptionByText() {
    // 找包含"职位描述"字样的最大文本块
    const candidates = document.querySelectorAll('div, section, article');
    let best = '';
    for (const el of candidates) {
      const text = getCleanText(el);
      if (text.includes('职位描述') && text.length > best.length && text.length < 5000) {
        best = text;
      }
    }

    // 如果没找到，尝试找最长的文本块（排除 body/html）
    if (!best) {
      for (const el of candidates) {
        const text = getCleanText(el);
        if (text.length > best.length && text.length < 5000) {
          best = text;
        }
      }
    }

    return best;
  }

  // 提取职位信息
  async function extractJobInfo() {
    try {
      console.log('Waiting for job elements to load...');
      console.log('Current URL:', location.href);

      // ===== 职位名称 =====
      const titleSelectors = [
        '.job-detail-box .job-name',
        '.job-detail-box .job-title',
        '.job-name',
        '.detail-top-title',
        '.job-title',
        'h1',
      ];

      // ===== 职位描述 =====
      const descSelectors = [
        '.job-detail-box .desc',
        '.job-detail-box .job-sec-text',
        '.job-detail-box .job-description',
        '.desc',
        '.detail-bottom-text',
        '.job-sec-text',
        '.job-description',
        '.job-detail',
      ];

      // 先等待核心元素（标题或描述）出现
      let titleEl = await waitForAny(titleSelectors, 8000);
      let descEl = await waitForAny(descSelectors, 8000);

      // 调试：打印当前页面的关键 DOM 信息
      console.log('Page DOM sample:', {
        url: location.href,
        hasJobDetailBox: !!document.querySelector('.job-detail-box'),
        hasJobName: !!document.querySelector('.job-name'),
        hasDesc: !!document.querySelector('.desc'),
        hasJobSecText: !!document.querySelector('.job-sec-text'),
        hasInfoPrimary: !!document.querySelector('.info-primary'),
        bodyTextLength: document.body ? document.body.textContent.length : 0,
      });

      let title = '';
      let description = '';

      // 如果没找到标题，尝试从页面标题兜底
      if (!titleEl) {
        console.log('Title element not found, trying page title fallback');
        title = extractTitleFromPage();
      } else {
        title = titleEl.textContent.trim();
      }

      // 如果没找到描述，尝试文本特征兜底
      if (!descEl) {
        console.log('Description element not found, trying text fallback');
        description = findDescriptionByText();
      } else {
        description = getCleanText(descEl);
      }

      // 如果通过选择器找到的描述很短，也尝试文本特征兜底
      if (!description || description.length < 50) {
        const fallbackDesc = findDescriptionByText();
        if (fallbackDesc.length > description.length) {
          description = fallbackDesc;
        }
      }

      // 清洗描述文本
      description = description
        .replace(/：/g, ':')
        .split('\n')
        .map((line) => line.trim())
        .filter((line) => line)
        .join('\n')
        .replace(/(?<!\n)(\d+\.)/g, '\n$1')
        .replace(/；(?!\s*\d+\.)/g, '；')
        .replace(/\n\s*\n/g, '\n')
        .replace(/^\n+/, '');

      // 智能提取经验要求
      const experience = extractExperienceAndLabels();

      const jobInfo = {
        title,
        experience,
        description,
      };

      // 验证内容
      if (!jobInfo.title || !jobInfo.description) {
        console.log('Missing content:', jobInfo);
        return null;
      }

      console.log('Successfully extracted job info:', jobInfo);
      return jobInfo;
    } catch (error) {
      console.error('Error extracting job info:', error);
      return null;
    }
  }

  // 监听来自popup的消息
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('Received message:', request);

    if (request.action === 'getJobInfo') {
      extractJobInfo().then((jobInfo) => {
        console.log('Sending response:', jobInfo);
        sendResponse(jobInfo);
      });
      return true;
    }
  });
}
