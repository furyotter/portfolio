# interview-helper-extension
 -可以抓取求职网站上的岗位详情和要求，利用AI生成针对性的面试题并提供答案（目前只支持Boss直聘网 https://www.zhipin.com/）  -It can crawl job details and requirements on job search websites, use AI to generate targeted interview questions and provide answers (currently only supports https://www.zhipin.com/ ）
