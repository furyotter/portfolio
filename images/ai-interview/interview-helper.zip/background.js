// 记录已注入的标签页
const injectedTabs = new Set();

// 监听标签页更新
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // 只在页面完成加载时执行，并且确保脚本只注入一次
  if (changeInfo.status === 'complete' && 
      tab.url?.includes('zhipin.com') && 
      !injectedTabs.has(tabId)) {
    
    console.log('Tab updated:', tabId, 'URL:', tab.url);
    
    // 注入内容脚本
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['content.js']
    }).then(() => {
      console.log('Content script injected successfully');
      injectedTabs.add(tabId);
    }).catch((err) => {
      console.error('Failed to inject content script:', err);
    });
  }
});

// 监听标签页移除事件，清理记录
chrome.tabs.onRemoved.addListener((tabId) => {
  injectedTabs.delete(tabId);
});
