// 默认配置（仅作为 fallback，实际值由用户在设置中输入并通过 chrome.storage 保存）
const config = {
  API_URL: "https://api.deepseek.com/v1/chat/completions",
  API_KEY: "",
  MODEL: "deepseek-chat"
};
